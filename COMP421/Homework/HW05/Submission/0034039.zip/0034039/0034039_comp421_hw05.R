#Reading data into memory
data <- read.csv(file = 'hw05_data_set.csv', header = TRUE)

#Splitting data into train and test sets
train_data <- data[1:100, ]
test_data <- data[101:133, ]
train_x <- train_data$x
train_y <- train_data$y
test_x <- test_data$x
test_y <- test_data$y

#Length of train_data and test_data
train_N <- length(train_y)
test_N <- length(test_y)

#Node impurity function
node_impurity <- function(data_y){
  g <- mean(data_y)
  return(sum((data_y - g)**2) / length(data_y))
}

#Split impurity function
split_impurity <- function(left_data_y, right_data_y){
  left_child_impurity <- node_impurity(left_data_y)
  right_child_impurity <- node_impurity(right_data_y)
  left_data_length <- length(left_data_y)
  right_data_length <- length(right_data_y)
  return(((left_child_impurity * left_data_length) +
           (right_child_impurity * right_data_length)) / 
           (left_data_length + right_data_length))
}

#Decision tree fit and test function
decision_tree_fit_test <- function(P, plot_fit = FALSE, extract_rule = FALSE){
  #Create necessary data structures
  node_indices <- list()
  is_terminal <- c()
  need_split <- c()
  node_splits <- c()
  node_means <- c()
  
  #Putting all training instances into the root node
  node_indices <- list(1:train_N)
  is_terminal <- c(FALSE)
  need_split <- c(TRUE)
  
  #Decision tree learning algorithm
  while(TRUE){
    split_nodes <- which(need_split)
    if(length(split_nodes) == 0){
      break
    }
    for(split_node in split_nodes){
      data_indices <- node_indices[[split_node]]
      need_split[split_node] <- FALSE
      node_means[split_node] <- mean(train_y[data_indices])
      unique_values <- sort(unique(train_x[data_indices]))
      split_positions <- (unique_values[-1] + 
                            unique_values[-length(unique_values)]) / 2
      if(length(train_y[data_indices]) <= P || length(split_positions) == 0){
        is_terminal[split_node] <- TRUE
        next
      }
      is_terminal[split_node] <- FALSE
      
      split_impurities <- rep(0, length(split_positions))
      for(s in 1:length(split_positions)){
        left_indices <- data_indices[which(train_x[data_indices] <=
                                             split_positions[s])]
        right_indices <- data_indices[which(train_x[data_indices] >
                                              split_positions[s])]
        split_impurities[s] <- split_impurity(train_y[left_indices], 
                                              train_y[right_indices])
      }
      best_split <- split_positions[which.min(split_impurities)]
      node_splits[split_node] <- best_split
      
      left_indices <- data_indices[which(train_x[data_indices] <= best_split)]
      node_indices[[2 * split_node]] <- left_indices
      is_terminal[2 * split_node] <- FALSE
      need_split[2 * split_node] <- TRUE
      
      right_indices <- data_indices[which(train_x[data_indices] > best_split)]
      node_indices[[2 * split_node + 1]] <- right_indices
      is_terminal[2 * split_node + 1 ] <- FALSE
      need_split[2 * split_node + 1] <- TRUE
    }
  }
  
  if(plot_fit){
    #Plotting train_data, test_data and decision tree fit
    plot(x = train_x,
         y = train_y,
         xlab = 'x',
         ylab = 'y',
         type = 'p',
         pch = 20,
         col = 'blue',
         xlim = c(0, 60))
    points(x = test_x,
           y = test_y,
           type = 'p',
           pch = 20,
           col = 'red')
    mock_x <- seq(from = 0, to = 60, by = 0.01)
    g_scores <- rep(0, length(mock_x))
    for(i in 1:length(mock_x)){
      index <- 1
      while(TRUE){
        if(is_terminal[index] == TRUE){
          g_scores[i] <- node_means[index]
          break
        }else{
          if(mock_x[i] <= node_splits[index]){
            index <- 2 * index
          }else{
            index <- 2 * index + 1
          }
        }
      }
    }
    lines(x = mock_x,
          y = g_scores,
          xlab = 'x',
          ylab = 'y',
          type = 'S')
    title(main = 'Decision Tree with P = 10')
    legend(x = max(data$x) + 4.8, y= max(data$y) + 8, legend = c('training', 'test'),
           col = c('blue', 'red'), pch = 20, xjust = 1, yjust = 1)
  }
  
  if(extract_rule){
    #Extracting rules
    terminal_nodes <- which(is_terminal)
    for (terminal_node in terminal_nodes) {
      index <- terminal_node
      rules <- c()
      while (index > 1) {
        parent <- floor(index / 2)
        if (index %% 2 == 0) {
          rules <- c(sprintf("x < %g", node_splits[parent]), rules)
        } else {
          rules <- c(sprintf("x >= %g", node_splits[parent]), rules)
        }
        index <- parent
      }
      print(sprintf("{%s} => [%s]", paste0(rules, collapse = " AND "), 
                    paste0(node_means[terminal_node])))
    }
  }
  
  #Testing decision tree with test_data
  test_y_hat <- rep(0, test_N)
  for(i in 1:test_N){
    index <- 1
    while(TRUE){
      if(is_terminal[index] == TRUE){
        test_y_hat[i] <- node_means[index]
        break
      }else{
        if(test_x[i] <= node_splits[index]){
          index <- 2 * index
        }else{
          index <- 2 * index + 1
        }
      }
    }
  }
  
  #Calculating RMSE for test_data
  test_data_rmse <- sqrt(sum((test_y - test_y_hat)**2) / test_N)
  return(test_data_rmse)
}

#User defined parameter P
P <- 10

#Fitting and testing decision tree with the train_data
test_data_rmse <- decision_tree_fit_test(P = P, plot_fit = TRUE, extract_rule = TRUE)
cat('RMSE is', test_data_rmse, 'when P is', P)

#Testing different P values from 1 to 20
P_list <- 1:20
rmse_list <- c()
for(P in P_list){
  rmse_list <- c(rmse_list, decision_tree_fit_test(P = P, 
                                                   plot_fit = FALSE, 
                                                   extract_rule = FALSE))
}

#Plotting RMSE vs P plot
plot(x = P_list,
     y = rmse_list,
     xlab = 'P',
     ylab = 'RMSE',
     type = 'b')

